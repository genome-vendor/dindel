 /*==========================================================================
                SeqAn - The Library for Sequence Analysis
                          http://www.seqan.de 
 ============================================================================
  Copyright (C) 2007

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

 ============================================================================
  $Id: score_chain.h 3038 2008-11-12 21:07:25Z doering@PCPOOL.MI.FU-BERLIN.DE $
 ==========================================================================*/

#ifndef SEQAN_HEADER_SCORE_CHAIN_H
#define SEQAN_HEADER_SCORE_CHAIN_H

namespace seqan
{

//////////////////////////////////////////////////////////////////////////////

//struct Manhattan;

struct Zero;

struct ChainSoP;

//////////////////////////////////////////////////////////////////////////////



}// namespace seqan

#endif //#ifndef SEQAN_HEADER_...
